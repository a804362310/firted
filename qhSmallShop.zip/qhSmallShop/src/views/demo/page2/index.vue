<template>
  <d2-container>
    <template slot="header">Page 2 header</template>
    Hello World
  </d2-container>
</template>

<script>
export default {
  name: 'page2'
}
</script>
