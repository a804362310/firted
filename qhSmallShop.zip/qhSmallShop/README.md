### 项目介绍
本项目基于[D2Admin](https://github.com/d2-projects/d2-admin)进行的二次开发，服务于小商店后台管理系统。
